-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 192.168.56.101
-- Tiempo de generación: 12-11-2025 a las 19:12:19
-- Versión del servidor: 8.0.44
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `taller_mantenimiento`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calendario`
--

CREATE TABLE `calendario` (
  `id_evento` int NOT NULL,
  `fecha_evento` date NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos`
--

CREATE TABLE `equipos` (
  `id_equipo` int NOT NULL,
  `fecha_ingreso` date DEFAULT (curdate()),
  `vehiculo` varchar(100) NOT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `serie` varchar(50) DEFAULT NULL,
  `tecnico_asignado` varchar(100) DEFAULT NULL,
  `tipo_servicio` varchar(50) DEFAULT NULL,
  `motorizacion` varchar(50) DEFAULT NULL,
  `estado` varchar(50) DEFAULT 'En diagnóstico',
  `costo_inicial` decimal(10,2) DEFAULT NULL,
  `costo_final` decimal(10,2) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `observacion` text,
  `observacion_final` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `equipos`
--

INSERT INTO `equipos` (`id_equipo`, `fecha_ingreso`, `vehiculo`, `marca`, `categoria`, `serie`, `tecnico_asignado`, `tipo_servicio`, `motorizacion`, `estado`, `costo_inicial`, `costo_final`, `fecha_salida`, `observacion`, `observacion_final`) VALUES
(6, '2025-11-12', 'Toyota Hilux 4x4', 'Toyota', 'Pickup', 'THX2025PAN', 'Jose López', 'Revisión General y Cambio de Aceite', 'Motor 2.8L Turbo Diesel', 'En diagnóstico', 150.00, 350.00, '2025-11-12', NULL, 'Cambio completo de aceite y revisión del sistema eléctrico');

--
-- Disparadores `equipos`
--
DELIMITER $$
CREATE TRIGGER `actualizar_fecha_salida` BEFORE UPDATE ON `equipos` FOR EACH ROW BEGIN
    -- Si el registro tiene costo_final y no tenía fecha_salida antes
    IF NEW.costo_final IS NOT NULL AND OLD.fecha_salida IS NULL THEN
        SET NEW.fecha_salida = CURDATE();
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimientos`
--

CREATE TABLE `mantenimientos` (
  `id_mantenimiento` int NOT NULL,
  `id_equipo` int NOT NULL COMMENT 'Relación con la tabla equipos',
  `tipo_mantenimiento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Preventivo / Correctivo / Predictivo',
  `estado` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'por_hacer /en_espera / revision / terminado',
  `avance` int NOT NULL COMMENT 'Porcentaje 0-100',
  `fecha_inicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_fin` date DEFAULT NULL COMMENT 'Se completa al terminar',
  `tecnico_asignado` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nombre del técnico',
  `notas` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Detalles del progreso',
  `es_tarea_activa` tinyint(1) DEFAULT '1',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_programada` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `mantenimientos`
--

INSERT INTO `mantenimientos` (`id_mantenimiento`, `id_equipo`, `tipo_mantenimiento`, `estado`, `avance`, `fecha_inicio`, `fecha_fin`, `tecnico_asignado`, `notas`, `es_tarea_activa`, `fecha_creacion`, `fecha_programada`) VALUES
(1, 5, 'Mantenimiento inicial', 'Terminado', 100, '2025-11-11 02:58:37', NULL, 'Jose Lopéz', 'El cliente reporta ruido al frenar y vibración leve en el pedal.\nCambio de frenos y revisión general', 1, '2025-11-11 01:58:37', '2025-11-11'),
(3, 6, 'Revisión General', 'Terminado', 100, '2025-11-12 04:09:53', '2025-11-12', 'Jose López', 'Revisión inicial del sistema de frenos y motor', 1, '2025-11-12 03:09:53', NULL),
(4, 7, 'Mantenimiento inicial', 'Esperando repuestos', 75, '2025-11-12 18:22:12', NULL, 'Andrés Quintero', 'Mantenimiento general y diagnóstico de motor', 1, '2025-11-12 17:22:12', '2025-11-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_inicial`
--

CREATE TABLE `registro_inicial` (
  `id_registro` int NOT NULL,
  `fecha_ingreso` date DEFAULT (curdate()),
  `vehiculo` varchar(100) NOT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `serie` varchar(50) DEFAULT NULL,
  `tipo_servicio` varchar(50) DEFAULT NULL,
  `estado` varchar(50) DEFAULT 'En diagnóstico',
  `motorizacion` varchar(50) DEFAULT NULL,
  `costo_inicial` decimal(10,2) DEFAULT '0.00',
  `observacion` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `registro_inicial`
--

INSERT INTO `registro_inicial` (`id_registro`, `fecha_ingreso`, `vehiculo`, `marca`, `categoria`, `serie`, `tipo_servicio`, `estado`, `motorizacion`, `costo_inicial`, `observacion`) VALUES
(1, '2025-11-09', 'Toyota Hilux', 'Toyota', 'Pick-up', 'ABC12345', 'Preventivo', 'En diagnóstico', 'Gasolina', 170.00, ''),
(2, '2025-11-09', 'Honda Civic', 'Honda', 'Sedan', 'DEF456', 'Preventivo', 'En reparación', 'Gasolina', 200.00, 'Cambio de aceite'),
(3, '2025-11-09', 'Ford F-150', 'Ford', 'Pick-up', 'GHI789', 'Correctivo', 'Esperando repuestos', 'Diésel', 500.00, 'Sistema de suspensión dañado'),
(4, '2025-11-10', 'Toyota Corolla', 'Toyota', 'Sedán', 'TY-2025-XB', 'Correctivo', 'En diagnóstico', 'Gasolina', 150.00, 'Se reemplazo de frenos, aceite y batería.'),
(5, '2025-11-11', 'Kia Sportage 2018', 'Kia', 'SUV', 'SPT2018-AX45', 'Correctivo', 'En diagnóstico', 'Gasolina', 150.00, 'asdagrgaregaeg'),
(6, '2025-11-12', 'Toyota Hilux 4x4', 'Toyota', 'Pickup', 'THX2025PAN', 'Revisión General y Cambio de Aceite', 'En diagnóstico', 'Motor 2.8L Turbo Diesel', 150.00, NULL),
(7, '2025-11-12', 'Toyota Corolla XLi', 'Toyota', 'Sedán', 'JTDBR32E95012', 'Preventivo', 'En diagnóstico', 'Gasolina', 85.00, 'Cliente reporta vibración leve al encender el vehículo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuarios` int NOT NULL,
  `usuario` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contrasena` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `rol` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuarios`, `usuario`, `contrasena`, `rol`) VALUES
(1, 'admin', 'hola14', 'administrador'),
(2, 'admin2', 'hola14', 'administrador'),
(3, 'Ana', 'clave123', 'empleado');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `calendario`
--
ALTER TABLE `calendario`
  ADD PRIMARY KEY (`id_evento`);

--
-- Indices de la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD PRIMARY KEY (`id_equipo`);

--
-- Indices de la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  ADD PRIMARY KEY (`id_mantenimiento`),
  ADD KEY `id_equipo` (`id_equipo`),
  ADD KEY `id_equipo_2` (`id_equipo`);

--
-- Indices de la tabla `registro_inicial`
--
ALTER TABLE `registro_inicial`
  ADD PRIMARY KEY (`id_registro`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuarios`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `calendario`
--
ALTER TABLE `calendario`
  MODIFY `id_evento` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `equipos`
--
ALTER TABLE `equipos`
  MODIFY `id_equipo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  MODIFY `id_mantenimiento` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `registro_inicial`
--
ALTER TABLE `registro_inicial`
  MODIFY `id_registro` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuarios` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  ADD CONSTRAINT `fk_mantenimiento_equipo` FOREIGN KEY (`id_equipo`) REFERENCES `registro_inicial` (`id_registro`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
