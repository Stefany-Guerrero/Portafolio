package vista;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.*;
import conexion.ConexionBD;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelMantenimiento extends javax.swing.JPanel {

    // ===============================================================
    // 🔹 CONSTRUCTOR PRINCIPAL
    // ===============================================================
    public PanelMantenimiento() {
        initComponents();

        setLayout(new BorderLayout());
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        panelSuperior.setBackground(new Color(230, 240, 250));

        JLabel titulo = new JLabel("🛠️ Panel de Mantenimientos");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(new Color(28, 67, 95));

        JButton btnRefrescar = new JButton("Actualizar 🔃");
        btnRefrescar.setFocusPainted(false);
        btnRefrescar.setBackground(new Color(28, 67, 95));
        btnRefrescar.setForeground(Color.WHITE);
        btnRefrescar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnRefrescar.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        btnRefrescar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btnRefrescar.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                btnRefrescar.setBackground(new Color(20, 55, 80));
            }
            @Override public void mouseExited(MouseEvent e) {
                btnRefrescar.setBackground(new Color(28, 67, 95));
            }
        });

        btnRefrescar.addActionListener(e -> cargarMantenimientos());

        panelSuperior.add(titulo);
        panelSuperior.add(btnRefrescar);
        add(panelSuperior, BorderLayout.NORTH);
        add(panelColumnas, BorderLayout.CENTER);

        configurarDragAndDrop();
        cargarMantenimientos();
    }

    // ===============================================================
    // 🔹 CONFIGURAR DRAG & DROP ENTRE COLUMNAS
    // ===============================================================
    private void configurarPanelDrop(JPanel panel, String estadoDestino) {
        panel.setTransferHandler(new TransferHandler() {
            @Override
            public boolean canImport(TransferSupport support) {
                return support.isDataFlavorSupported(DataFlavor.stringFlavor);
            }

            @Override
            public boolean importData(TransferSupport support) {
                if (!canImport(support)) return false;
                try {
                    String taskId = (String) support.getTransferable()
                            .getTransferData(DataFlavor.stringFlavor);
                    if (actualizarEstadoMantenimiento(taskId, estadoDestino)) {
                        cargarMantenimientos();
                        return true;
                    }
                } catch (Exception e) { e.printStackTrace(); }
                return false;
            }
        });
    }

    private void configurarDragAndDrop() {
        configurarPanelDrop(panelPorHacer, "En diagnóstico");
        configurarPanelDrop(panelEnEspera, "En reparación");
        configurarPanelDrop(panelEnRevision, "Esperando repuestos");
        configurarPanelDrop(panelTerminado, "Terminado");
    }

    // ===============================================================
    // 🔹 ACTUALIZAR ESTADO (con sincronización a EQUIPOS)
    // ===============================================================
    private boolean actualizarEstadoMantenimiento(String taskId, String nuevoEstado) {
        int nuevoAvance = switch (nuevoEstado.toLowerCase()) {
            case "en diagnóstico" -> 0;
            case "en reparación" -> 50;
            case "esperando repuestos" -> 75;
            case "terminado" -> 100;
            default -> 0;
        };

        String sql = (nuevoEstado.equalsIgnoreCase("Terminado"))
                ? "UPDATE mantenimientos SET estado=?, avance=?, fecha_final=CURDATE() WHERE id_mantenimiento=?"
                : "UPDATE mantenimientos SET estado=?, avance=?, fecha_programada=CURDATE() WHERE id_mantenimiento=?";

        try (Connection cn = new ConexionBD().conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, nuevoAvance);
            ps.setString(3, taskId);
            ps.executeUpdate();

            // 🧩 Si el mantenimiento terminó, sincronizar con tabla EQUIPOS
            if (nuevoEstado.equalsIgnoreCase("Terminado")) {
                try (PreparedStatement ps2 = cn.prepareStatement(
                    """
                    UPDATE equipos e
                    JOIN mantenimientos m ON e.id_equipo = m.id_equipo
                    SET e.estado = 'Finalizado',
                        e.tecnico_asignado = m.tecnico_asignado,
                        e.fecha_salida = CURDATE()
                    WHERE m.id_mantenimiento = ?
                    """
                )) {
                    ps2.setString(1, taskId);
                    ps2.executeUpdate();
                }
            }

            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al actualizar: " + e.getMessage());
            return false;
        }
    }

    // ===============================================================
    // 🔹 CARGAR MANTENIMIENTOS
    // ===============================================================
    private void cargarMantenimientos() {
        String sql = """
            SELECT m.id_mantenimiento, m.tipo_mantenimiento, m.estado,
                   m.tecnico_asignado, m.avance, m.notas, m.fecha_creacion,
                   r.vehiculo, r.marca, r.serie, r.motorizacion
            FROM mantenimientos m
            LEFT JOIN registro_inicial r ON m.id_equipo = r.id_registro
            ORDER BY m.fecha_creacion DESC
        """;

        try (Connection cn = new ConexionBD().conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            for (JPanel panel : new JPanel[]{panelPorHacer, panelEnEspera, panelEnRevision, panelTerminado})
                panel.removeAll();

            panelPorHacer.setLayout(new BoxLayout(panelPorHacer, BoxLayout.Y_AXIS));
            panelEnEspera.setLayout(new BoxLayout(panelEnEspera, BoxLayout.Y_AXIS));
            panelEnRevision.setLayout(new BoxLayout(panelEnRevision, BoxLayout.Y_AXIS));
            panelTerminado.setLayout(new BoxLayout(panelTerminado, BoxLayout.Y_AXIS));

            while (rs.next()) {
                String id = rs.getString("id_mantenimiento");
                String tipo = rs.getString("tipo_mantenimiento");
                String estado = rs.getString("estado");
                String tecnico = rs.getString("tecnico_asignado");
                String avance = rs.getString("avance");
                String notas = rs.getString("notas");
                String fechaCreacion = rs.getString("fecha_creacion");
                String vehiculo = rs.getString("vehiculo");
                String marca = rs.getString("marca");
                String serie = rs.getString("serie");
                String motorizacion = rs.getString("motorizacion");

                TaskCard card = new TaskCard(id, tipo, estado, tecnico, avance, notas,
                        vehiculo, marca, serie, motorizacion, fechaCreacion);

                card.setAlignmentX(Component.CENTER_ALIGNMENT);

                switch (estado.toLowerCase()) {
                    case "en diagnóstico" -> panelPorHacer.add(card);
                    case "en reparación" -> panelEnEspera.add(card);
                    case "esperando repuestos" -> panelEnRevision.add(card);
                    case "terminado" -> panelTerminado.add(card);
                    default -> panelPorHacer.add(card);
                }
            }

            actualizarVista();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar: " + e.getMessage());
        }
    }

    private void actualizarVista() {
        for (JPanel panel : new JPanel[]{panelPorHacer, panelEnEspera, panelEnRevision, panelTerminado}) {
            panel.revalidate();
            panel.repaint();
        }
    }

    // ===============================================================
    // 🔹 TARJETA DE MANTENIMIENTO (INTERFAZ VISUAL)
    // ===============================================================
    class TaskCard extends JPanel {
        public TaskCard(String id, String tipo, String estado, String tecnico,
                        String avance, String notas, String vehiculo,
                        String marca, String serie, String motorizacion,
                        String fechaCreacion) {

            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setPreferredSize(new Dimension(260, 220));
            setMaximumSize(new Dimension(260, 220));

            Color fondo = switch (estado.toLowerCase()) {
                case "en diagnóstico" -> new Color(220, 240, 255);
                case "en reparación" -> new Color(255, 250, 200);
                case "esperando repuestos" -> new Color(255, 230, 200);
                case "terminado" -> new Color(210, 255, 210);
                default -> new Color(245, 245, 245);
            };
            setBackground(fondo);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(150, 150, 150)),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));

            boolean terminado = estado.equalsIgnoreCase("Terminado");

            JLabel lblFolio = new JLabel("📄 Folio: " + id);
            lblFolio.setFont(new Font("Segoe UI", Font.BOLD, 13));
            JLabel lblVehiculo = new JLabel("🚗 " + vehiculo + " (" + marca + ")");
            JLabel lblEstado = new JLabel("Estado: " + estado);
            JLabel lblFecha = new JLabel("📅 Creado: " + fechaCreacion);

            // 👷 Técnico
            JPanel tecnicoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
            tecnicoPanel.setOpaque(false);
            JLabel lblTecnico = new JLabel("👷 Técnico:");
            JTextField txtTecnico = new JTextField(10);
            txtTecnico.setText(tecnico != null ? tecnico : "");
            txtTecnico.setEditable(!terminado);

            JButton btnGuardarTecnico = new JButton("💾");
            btnGuardarTecnico.setMargin(new Insets(1, 5, 1, 5));
            btnGuardarTecnico.setEnabled(!terminado);

            btnGuardarTecnico.addActionListener(e -> {
                if (!terminado) guardarCampo("tecnico_asignado", txtTecnico.getText(), id, "Técnico");
            });

            tecnicoPanel.add(lblTecnico);
            tecnicoPanel.add(txtTecnico);
            tecnicoPanel.add(btnGuardarTecnico);

            // 📝 Notas
            JTextArea txtNotas = new JTextArea(notas == null ? "" : notas, 3, 20);
            txtNotas.setLineWrap(true);
            txtNotas.setWrapStyleWord(true);
            txtNotas.setEditable(!terminado);
            txtNotas.setBackground(Color.WHITE);
            txtNotas.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

            JButton btnGuardarNotas = new JButton("💾 Guardar Nota");
            btnGuardarNotas.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            btnGuardarNotas.setEnabled(!terminado);
            btnGuardarNotas.addActionListener(e -> {
                if (!terminado) guardarCampo("notas", txtNotas.getText(), id, "Nota");
            });

            JScrollPane scrollNotas = new JScrollPane(txtNotas);
            scrollNotas.setPreferredSize(new Dimension(230, 60));

            add(lblFolio);
            add(lblVehiculo);
            add(lblEstado);
            add(tecnicoPanel);
            add(lblFecha);
            add(scrollNotas);
            add(btnGuardarNotas);

            // 🚫 No permitir arrastrar si está terminado
            setTransferHandler(new TransferHandler("text") {
                @Override protected Transferable createTransferable(JComponent c) {
                    return new StringSelection(id);
                }
                @Override public int getSourceActions(JComponent c) {
                    return terminado ? TransferHandler.NONE : TransferHandler.MOVE;
                }
            });

            if (!terminado) {
                addMouseListener(new MouseAdapter() {
                    @Override public void mousePressed(MouseEvent e) {
                        JComponent comp = (JComponent) e.getSource();
                        comp.getTransferHandler().exportAsDrag(comp, e, TransferHandler.MOVE);
                    }
                });
            }
        }

        private void guardarCampo(String campo, String valor, String id, String tipoCampo) {
            try (Connection cn = new ConexionBD().conectar()) {
                String sql = "UPDATE mantenimientos SET " + campo + "=? WHERE id_mantenimiento=?";
                try (PreparedStatement ps = cn.prepareStatement(sql)) {
                    ps.setString(1, valor.trim());
                    ps.setInt(2, Integer.parseInt(id));
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "✅ " + tipoCampo + " actualizado correctamente");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "❌ Error al guardar " + tipoCampo + ": " + ex.getMessage());
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelSuperior1 = new javax.swing.JPanel();
        panelColumnas = new javax.swing.JPanel();
        scrollPorHacer = new javax.swing.JScrollPane();
        panelPorHacer = new javax.swing.JPanel();
        scrollEnEspera = new javax.swing.JScrollPane();
        panelEnEspera = new javax.swing.JPanel();
        scrollEnRevision = new javax.swing.JScrollPane();
        panelEnRevision = new javax.swing.JPanel();
        scrollTerminado = new javax.swing.JScrollPane();
        panelTerminado = new javax.swing.JPanel();
        panelSuperior = new javax.swing.JPanel();

        setMaximumSize(new java.awt.Dimension(1920, 1080));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setPreferredSize(new java.awt.Dimension(1920, 1080));
        setLayout(new java.awt.BorderLayout());

        panelSuperior1.setBackground(new java.awt.Color(233, 239, 245));
        add(panelSuperior1, java.awt.BorderLayout.PAGE_START);

        panelColumnas.setLayout(new java.awt.GridLayout(1, 4));

        scrollPorHacer.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Por Hacer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14), new java.awt.Color(80, 80, 80))); // NOI18N

        panelPorHacer.setBackground(new java.awt.Color(204, 229, 255));

        javax.swing.GroupLayout panelPorHacerLayout = new javax.swing.GroupLayout(panelPorHacer);
        panelPorHacer.setLayout(panelPorHacerLayout);
        panelPorHacerLayout.setHorizontalGroup(
            panelPorHacerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2413, Short.MAX_VALUE)
        );
        panelPorHacerLayout.setVerticalGroup(
            panelPorHacerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1162, Short.MAX_VALUE)
        );

        scrollPorHacer.setViewportView(panelPorHacer);

        panelColumnas.add(scrollPorHacer);

        scrollEnEspera.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "En Espera", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14), new java.awt.Color(80, 80, 80))); // NOI18N

        panelEnEspera.setBackground(new java.awt.Color(255, 242, 204));

        javax.swing.GroupLayout panelEnEsperaLayout = new javax.swing.GroupLayout(panelEnEspera);
        panelEnEspera.setLayout(panelEnEsperaLayout);
        panelEnEsperaLayout.setHorizontalGroup(
            panelEnEsperaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2398, Short.MAX_VALUE)
        );
        panelEnEsperaLayout.setVerticalGroup(
            panelEnEsperaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1082, Short.MAX_VALUE)
        );

        scrollEnEspera.setViewportView(panelEnEspera);

        panelColumnas.add(scrollEnEspera);

        panelEnRevision.setBackground(new java.awt.Color(255, 224, 204));
        panelEnRevision.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "En Revisión", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14), new java.awt.Color(80, 80, 80))); // NOI18N

        javax.swing.GroupLayout panelEnRevisionLayout = new javax.swing.GroupLayout(panelEnRevision);
        panelEnRevision.setLayout(panelEnRevisionLayout);
        panelEnRevisionLayout.setHorizontalGroup(
            panelEnRevisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2396, Short.MAX_VALUE)
        );
        panelEnRevisionLayout.setVerticalGroup(
            panelEnRevisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1080, Short.MAX_VALUE)
        );

        scrollEnRevision.setViewportView(panelEnRevision);

        panelColumnas.add(scrollEnRevision);

        panelTerminado.setBackground(new java.awt.Color(217, 240, 211));
        panelTerminado.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Terminado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 14), new java.awt.Color(80, 80, 80))); // NOI18N

        javax.swing.GroupLayout panelTerminadoLayout = new javax.swing.GroupLayout(panelTerminado);
        panelTerminado.setLayout(panelTerminadoLayout);
        panelTerminadoLayout.setHorizontalGroup(
            panelTerminadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2396, Short.MAX_VALUE)
        );
        panelTerminadoLayout.setVerticalGroup(
            panelTerminadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1080, Short.MAX_VALUE)
        );

        scrollTerminado.setViewportView(panelTerminado);

        panelColumnas.add(scrollTerminado);

        add(panelColumnas, java.awt.BorderLayout.CENTER);

        panelSuperior.setBackground(new java.awt.Color(233, 239, 245));
        panelSuperior.setLayout(new java.awt.BorderLayout());
        add(panelSuperior, java.awt.BorderLayout.PAGE_END);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel panelColumnas;
    private javax.swing.JPanel panelEnEspera;
    private javax.swing.JPanel panelEnRevision;
    private javax.swing.JPanel panelPorHacer;
    private javax.swing.JPanel panelSuperior;
    private javax.swing.JPanel panelSuperior1;
    private javax.swing.JPanel panelTerminado;
    private javax.swing.JScrollPane scrollEnEspera;
    private javax.swing.JScrollPane scrollEnRevision;
    private javax.swing.JScrollPane scrollPorHacer;
    private javax.swing.JScrollPane scrollTerminado;
    // End of variables declaration//GEN-END:variables
}
