package vista;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer; // para centrar encabezados
import javax.swing.SwingConstants;                 // para alineación
import conexion.ConexionBD;
import java.math.BigDecimal; // (lo usaremos luego en los botones)

public class RegistroFinal extends javax.swing.JPanel {

    // ---------------------------------------------------------------
    // CONSTRUCTOR
    // ---------------------------------------------------------------
    public RegistroFinal() {
        initComponents();

        // Configuración de la tabla
        tablaVehiculo.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tablaVehiculo.setAutoCreateRowSorter(true);
        tablaVehiculo.setFillsViewportHeight(true);
        tablaVehiculo.getTableHeader().setReorderingAllowed(false);

        // Click en fila -> carga campos del panel derecho
        tablaVehiculo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int fila = tablaVehiculo.getSelectedRow();
                if (fila >= 0) {
                    // ID
                    txtID.setText(String.valueOf(tablaVehiculo.getValueAt(fila, 0)));

                    // Evitar mostrar "null" en campos
                    Object costoObj = tablaVehiculo.getValueAt(fila, 11);
                    Object obsObj   = tablaVehiculo.getValueAt(fila, 12);

                    txtCostoFinal.setText(costoObj == null ? "" : String.valueOf(costoObj));
                    txtObservacionFinal.setText(obsObj == null ? "" : String.valueOf(obsObj));
                }
            }
        });

        // Si por cualquier razón NetBeans aún no creó txtID, lo añadimos oculto
        if (txtID == null) {
            txtID = new javax.swing.JTextField();
            txtID.setVisible(false);
            panelFormulario.add(txtID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 80, -1));
        }

        // Cargar datos al abrir
        cargarDatosVehiculos();

        // Ajustes visuales de columnas
        tablaVehiculo.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        int[] anchos = {
            40,   // ID
            100,  // Fecha Ingreso
            160,  // Vehículo
            100,  // Marca
            90,   // Categoría
            110,  // Serie
            150,  // Tipo Servicio
            120,  // Estado Mant.
            120,  // Técnico
            120,  // Motorización
            90,   // Costo Inicial
            100,  // Costo Final
            260,  // Observación Final
            110   // Fecha Salida
        };
        for (int i = 0; i < anchos.length; i++) {
            tablaVehiculo.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }

        // Centrar encabezados
        DefaultTableCellRenderer header = (DefaultTableCellRenderer) tablaVehiculo.getTableHeader().getDefaultRenderer();
        header.setHorizontalAlignment(SwingConstants.CENTER);
    } // <--- ✅ AQUÍ TERMINA EL CONSTRUCTOR



    // ---------------------------------------------------------------
    // CARGAR DATOS (finalizados/terminados)
    // ---------------------------------------------------------------
    private void cargarDatosVehiculos() {
        DefaultTableModel modelo = new DefaultTableModel(new Object[]{
            "ID", "Fecha Ingreso", "Vehículo", "Marca", "Categoría", "Serie",
            "Tipo Servicio", "Estado Mant.", "Técnico", "Motorización",
            "Costo Inicial", "Costo Final", "Observación Final", "Fecha Salida"
        }, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaVehiculo.setModel(modelo);

        String sql = """
            SELECT
                r.id_registro AS id_equipo,
                r.fecha_ingreso,
                r.vehiculo, r.marca, r.categoria, r.serie,
                r.tipo_servicio,
                m.estado AS estado_mant,
                COALESCE(NULLIF(m.tecnico_asignado,''), 'Sin asignar') AS tecnico,
                r.motorizacion,
                r.costo_inicial,
                e.costo_final,
                e.observacion_final,
                e.fecha_salida
            FROM registro_inicial r
            LEFT JOIN (
                SELECT mm.*
                FROM mantenimientos mm
                WHERE mm.fecha_creacion = (
                    SELECT MAX(m2.fecha_creacion)
                    FROM mantenimientos m2
                    WHERE m2.id_equipo = mm.id_equipo
                )
            ) m  ON m.id_equipo = r.id_registro
            LEFT JOIN equipos e ON e.id_equipo = r.id_registro
            WHERE m.estado = 'Terminado'
            ORDER BY COALESCE(e.fecha_salida, r.fecha_ingreso) DESC
        """;

        try (Connection cn = new ConexionBD().conectar();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_equipo"),
                    rs.getDate("fecha_ingreso"),
                    rs.getString("vehiculo"),
                    rs.getString("marca"),
                    rs.getString("categoria"),
                    rs.getString("serie"),
                    rs.getString("tipo_servicio"),
                    rs.getString("estado_mant"),
                    rs.getString("tecnico"),
                    rs.getString("motorizacion"),
                    rs.getBigDecimal("costo_inicial"),
                    rs.getBigDecimal("costo_final"),
                    // No mostrar "null" en observación
                    rs.getString("observacion_final") == null ? "" : rs.getString("observacion_final"),
                    rs.getDate("fecha_salida")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al cargar datos: " + e.getMessage());
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        split = new javax.swing.JSplitPane();
        scrollTabla = new javax.swing.JScrollPane();
        tablaVehiculo = new javax.swing.JTable();
        panelFormulario = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblCostoFinal = new javax.swing.JLabel();
        txtCostoFinal = new javax.swing.JTextField();
        lblObservacionFinal = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObservacionFinal = new javax.swing.JTextArea();
        btnActualizar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnFinalizar = new javax.swing.JButton();

        setName(""); // NOI18N
        setLayout(new java.awt.BorderLayout());

        split.setDividerLocation(1100);
        split.setDividerSize(10);
        split.setResizeWeight(1.0);
        split.setMaximumSize(new java.awt.Dimension(1920, 1080));
        split.setMinimumSize(new java.awt.Dimension(1920, 1080));
        split.setOneTouchExpandable(true);
        split.setPreferredSize(new java.awt.Dimension(1920, 1080));

        scrollTabla.setForeground(new java.awt.Color(4, 62, 80));
        scrollTabla.setMaximumSize(new java.awt.Dimension(1800, 1080));
        scrollTabla.setMinimumSize(new java.awt.Dimension(1200, 960));
        scrollTabla.setOpaque(false);
        scrollTabla.setPreferredSize(new java.awt.Dimension(1800, 1080));

        tablaVehiculo.setBackground(new java.awt.Color(44, 62, 80));
        tablaVehiculo.setForeground(new java.awt.Color(255, 255, 255));
        tablaVehiculo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaVehiculo.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tablaVehiculo.setMaximumSize(new java.awt.Dimension(1900, 1080));
        tablaVehiculo.setMinimumSize(null);
        tablaVehiculo.setName(""); // NOI18N
        tablaVehiculo.setPreferredSize(new java.awt.Dimension(1900, 1080));
        scrollTabla.setViewportView(tablaVehiculo);

        split.setLeftComponent(scrollTabla);

        panelFormulario.setBackground(new java.awt.Color(233, 239, 245));
        panelFormulario.setMaximumSize(new java.awt.Dimension(320, 1080));
        panelFormulario.setMinimumSize(new java.awt.Dimension(320, 1080));
        panelFormulario.setPreferredSize(new java.awt.Dimension(320, 1080));
        panelFormulario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setBackground(new java.awt.Color(4, 62, 80));
        lblTitulo.setFont(new java.awt.Font("Arial Black", 1, 20)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(4, 62, 80));
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Registro Final");
        panelFormulario.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 15, 450, 36));

        lblCostoFinal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCostoFinal.setText("Costo Final:");
        panelFormulario.add(lblCostoFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));

        txtCostoFinal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCostoFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCostoFinalActionPerformed(evt);
            }
        });
        panelFormulario.add(txtCostoFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 150, -1));

        lblObservacionFinal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblObservacionFinal.setText("Observación Final:");
        panelFormulario.add(lblObservacionFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

        txtObservacionFinal.setColumns(20);
        txtObservacionFinal.setRows(5);
        jScrollPane2.setViewportView(txtObservacionFinal);

        panelFormulario.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, -1, -1));

        btnActualizar.setBackground(new java.awt.Color(0, 61, 77));
        btnActualizar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar datos");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        panelFormulario.add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 640, 140, -1));

        btnLimpiar.setBackground(new java.awt.Color(220, 230, 240));
        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLimpiar.setForeground(new java.awt.Color(28, 67, 95));
        btnLimpiar.setText("Limpiar formulario");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        panelFormulario.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 640, -1, -1));

        btnFinalizar.setText("Finalizar");
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });
        panelFormulario.add(btnFinalizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 700, -1, -1));

        split.setRightComponent(panelFormulario);

        add(split, java.awt.BorderLayout.LINE_START);

        getAccessibleContext().setAccessibleName("");
    }// </editor-fold>//GEN-END:initComponents

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        txtID.setText("");
        txtCostoFinal.setText("");
        txtObservacionFinal.setText("");
        tablaVehiculo.clearSelection();
        JOptionPane.showMessageDialog(this, "🧹 Formulario limpiado correctamente.");

    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtCostoFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCostoFinalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCostoFinalActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
    if (txtID.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "⚠️ Selecciona un vehículo para actualizar.");
        return;
    }

    try (Connection cn = new ConexionBD().conectar();
         PreparedStatement ps = cn.prepareStatement(
             "UPDATE equipos SET costo_final=?, observacion_final=? WHERE id_equipo=?")) {

        ps.setBigDecimal(1, new BigDecimal(txtCostoFinal.getText().trim()));
        ps.setString(2, txtObservacionFinal.getText().trim());
        ps.setInt(3, Integer.parseInt(txtID.getText().trim()));
        ps.executeUpdate();

        JOptionPane.showMessageDialog(this, "🔄 Datos actualizados correctamente.");
        cargarDatosVehiculos();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Error al actualizar: " + e.getMessage());
    }

    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarActionPerformed
        if (txtID.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Debes seleccionar un vehículo antes de finalizar.");
            return;
        }

        String id = txtID.getText().trim();
        String costoFinal = txtCostoFinal.getText().trim();
        String observacionFinal = txtObservacionFinal.getText().trim();

        if (costoFinal.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Ingresa el costo final antes de finalizar.");
            return;
        }

        String sql = """
            UPDATE equipos e
            JOIN (
                SELECT id_equipo,
                       COALESCE(NULLIF(tecnico_asignado, ''), 'Sin asignar') AS tecnico
                FROM mantenimientos
                WHERE id_equipo = ?
                ORDER BY fecha_creacion DESC
                LIMIT 1
            ) m ON m.id_equipo = e.id_equipo
            SET e.tecnico_asignado = m.tecnico,
                e.costo_final = ?,
                e.observacion_final = ?,
                e.fecha_salida = CURDATE()
            WHERE e.id_equipo = ?;
        """;

        try (Connection cn = new ConexionBD().conectar();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(id)); // subquery
            ps.setBigDecimal(2, new BigDecimal(costoFinal));
            ps.setString(3, observacionFinal);
            ps.setInt(4, Integer.parseInt(id)); // WHERE
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "✅ Vehículo finalizado correctamente.\n📅 Fecha de salida registrada automáticamente.");
            cargarDatosVehiculos();
            txtCostoFinal.setText("");
            txtObservacionFinal.setText("");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al finalizar: " + e.getMessage());
        }
    
    }//GEN-LAST:event_btnFinalizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCostoFinal;
    private javax.swing.JLabel lblObservacionFinal;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JPanel panelFormulario;
    private javax.swing.JScrollPane scrollTabla;
    private javax.swing.JSplitPane split;
    private javax.swing.JTable tablaVehiculo;
    private javax.swing.JTextField txtCostoFinal;
    private javax.swing.JTextArea txtObservacionFinal;
    // End of variables declaration//GEN-END:variables
private javax.swing.JTextField txtID;
}