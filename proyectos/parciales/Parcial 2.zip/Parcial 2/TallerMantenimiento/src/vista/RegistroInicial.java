package vista;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import conexion.ConexionBD;
import java.math.BigDecimal;
import java.util.ArrayList;

public class RegistroInicial extends javax.swing.JPanel {

    // ===============================================================
    // 🔹 CONSTRUCTOR PRINCIPAL
    // ===============================================================
    public RegistroInicial() {
        initComponents();
        cbCategoriaInicial.setSelectedIndex(-1);
        cbTipoServicioInicial.setSelectedIndex(-1);
        cbMotorizacionInicial.setSelectedIndex(-1);
        cargarDatosVehiculos();
    }

    // ===============================================================
    // 🔹 CARGAR VEHÍCULOS DESDE registro_inicial
    // ===============================================================
    private void cargarDatosVehiculos() {
        DefaultTableModel modelo = new DefaultTableModel(new Object[]{
            "ID", "Fecha Ingreso", "Vehículo", "Marca", "Categoría", "Serie",
            "Tipo Servicio", "Estado", "Motorización", "Costo Inicial", "Observación"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTable1.setModel(modelo);

        try (Connection cn = new ConexionBD().conectar()) {
            if (cn == null) {
                JOptionPane.showMessageDialog(this, "❌ No se pudo conectar a la base de datos.");
                return;
            }

            String sql = """
                SELECT id_registro, fecha_ingreso, vehiculo, marca, categoria, serie,
                       tipo_servicio, estado, motorizacion, costo_inicial, observacion
                FROM registro_inicial
            """;

            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_registro"),
                    rs.getString("fecha_ingreso"),
                    rs.getString("vehiculo"),
                    rs.getString("marca"),
                    rs.getString("categoria"),
                    rs.getString("serie"),
                    rs.getString("tipo_servicio"),
                    rs.getString("estado"),
                    rs.getString("motorizacion"),
                    rs.getBigDecimal("costo_inicial"),
                    rs.getString("observacion")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }

    // ===============================================================
    // 🔹 REGISTRAR VEHÍCULO + CREAR TAREA AUTOMÁTICA + SINCRONIZAR EQUIPOS
    // ===============================================================
    private void registrarVehiculo() {
        try {
            if (cbCategoriaInicial.getSelectedIndex() == -1 ||
                cbTipoServicioInicial.getSelectedIndex() == -1 ||
                cbMotorizacionInicial.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(this, "Completa todos los campos antes de registrar.");
                return;
            }

            try (Connection cn = new ConexionBD().conectar()) {
                if (cn == null) {
                    JOptionPane.showMessageDialog(this, "❌ No se pudo conectar a la base de datos.");
                    return;
                }

                // 🧩 1️⃣ Insertar vehículo en registro_inicial
                String sql = """
                    INSERT INTO registro_inicial 
                    (fecha_ingreso, vehiculo, marca, categoria, serie, tipo_servicio, estado, motorizacion, costo_inicial, observacion)
                    VALUES (CURDATE(), ?, ?, ?, ?, ?, 'En diagnóstico', ?, ?, ?)
                """;

                PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, txtEquipoInicial.getText());
                ps.setString(2, txtMarcaInicial.getText());
                ps.setString(3, cbCategoriaInicial.getSelectedItem().toString());
                ps.setString(4, txtSerieInicial.getText());
                ps.setString(5, cbTipoServicioInicial.getSelectedItem().toString());
                ps.setString(6, cbMotorizacionInicial.getSelectedItem().toString());
                ps.setBigDecimal(7, new BigDecimal(txtCostoInicialInicial.getText()));
                ps.setString(8, jTextArea1.getText());
                ps.executeUpdate();

                ResultSet rs = ps.getGeneratedKeys();
                int idVehiculo = 0;
                if (rs.next()) {
                    idVehiculo = rs.getInt(1);
                }

                // 🧩 2️⃣ Insertar también en la tabla EQUIPOS
                String sqlEquipos = """
                    INSERT INTO equipos (
                        fecha_ingreso, vehiculo, marca, categoria, serie, tipo_servicio,
                        estado, tecnico_asignado, motorizacion, costo_inicial, observacion
                    )
                    VALUES (CURDATE(), ?, ?, ?, ?, ?, 'En diagnóstico', 'Sin asignar', ?, ?, ?)
                """;
                try (PreparedStatement psEquipos = cn.prepareStatement(sqlEquipos)) {
                    psEquipos.setString(1, txtEquipoInicial.getText());
                    psEquipos.setString(2, txtMarcaInicial.getText());
                    psEquipos.setString(3, cbCategoriaInicial.getSelectedItem().toString());
                    psEquipos.setString(4, txtSerieInicial.getText());
                    psEquipos.setString(5, cbTipoServicioInicial.getSelectedItem().toString());
                    psEquipos.setString(6, cbMotorizacionInicial.getSelectedItem().toString());
                    psEquipos.setBigDecimal(7, new BigDecimal(txtCostoInicialInicial.getText()));
                    psEquipos.setString(8, jTextArea1.getText());
                    psEquipos.executeUpdate();
                }

                // 🧩 3️⃣ Crear tarea automática en MANTENIMIENTOS
                crearTareaAutomatica(idVehiculo);

                cargarDatosVehiculos();
                JOptionPane.showMessageDialog(this, "✅ Vehículo registrado, tarea creada y sincronizado con EQUIPOS.");

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al registrar vehículo: " + e.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "⚠️ Error inesperado: " + ex.getMessage());
        }
    }

    // ===============================================================
    // 🔹 CREAR TAREA AUTOMÁTICA EN MANTENIMIENTOS
    // ===============================================================
    private void crearTareaAutomatica(int idVehiculo) {
        try (Connection cn = new ConexionBD().conectar()) {
            if (cn == null) {
                JOptionPane.showMessageDialog(this, "❌ No hay conexión para crear tarea.");
                return;
            }

            String sql = """
                INSERT INTO mantenimientos 
                (id_equipo, tipo_mantenimiento, estado, avance, fecha_inicio, tecnico_asignado, notas)
                VALUES (?, ?, ?, ?, CURDATE(), ?, ?)
            """;

            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, idVehiculo);
            ps.setString(2, "Preventivo");
            ps.setString(3, "En diagnóstico");
            ps.setInt(4, 0);
            ps.setString(5, "Sin asignar");
            ps.setString(6, "Tarea creada automáticamente con el registro del vehículo.");
            ps.executeUpdate();

            System.out.println("✅ Tarea automática creada para el vehículo ID " + idVehiculo);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al crear tarea automática: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        JScrollPane = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        lblSerieInicial = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblEquipoInicial = new javax.swing.JLabel();
        txtEquipoInicial = new javax.swing.JTextField();
        lblMarcaInicial = new javax.swing.JLabel();
        txtMarcaInicial = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtSerieInicial = new javax.swing.JTextField();
        lblCategoriaInicial = new javax.swing.JLabel();
        cbCategoriaInicial = new javax.swing.JComboBox<>();
        lblTipoServicioInicial = new javax.swing.JLabel();
        cbTipoServicioInicial = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cbMotorizacionInicial = new javax.swing.JComboBox<>();
        lblCostoInicialInicial = new javax.swing.JLabel();
        txtCostoInicialInicial = new javax.swing.JTextField();
        lblObservacionInicial = new javax.swing.JLabel();
        jTextArea1 = new javax.swing.JTextArea();
        btnRegistrarInicial = new javax.swing.JButton();
        btnEliminarInicial = new javax.swing.JButton();
        btnActualizarInicial = new javax.swing.JButton();
        btnLimpiarInicial = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(1920, 1080));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setLayout(new java.awt.BorderLayout());

        jSplitPane1.setDividerLocation(1200);
        jSplitPane1.setMaximumSize(new java.awt.Dimension(720, 1080));
        jSplitPane1.setMinimumSize(new java.awt.Dimension(720, 1080));
        jSplitPane1.setOneTouchExpandable(true);
        jSplitPane1.setPreferredSize(new java.awt.Dimension(1920, 1080));

        JScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        JScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTable1.setBackground(new java.awt.Color(44, 62, 80));
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setMaximumSize(null);
        jTable1.setMinimumSize(null);
        jTable1.setPreferredSize(new java.awt.Dimension(1600, 1080));
        JScrollPane.setViewportView(jTable1);

        jSplitPane1.setLeftComponent(JScrollPane);

        lblSerieInicial.setBackground(new java.awt.Color(233, 239, 245));
        lblSerieInicial.setMaximumSize(new java.awt.Dimension(280, 1080));
        lblSerieInicial.setMinimumSize(new java.awt.Dimension(280, 1080));
        lblSerieInicial.setPreferredSize(new java.awt.Dimension(280, 1080));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(4, 62, 80));
        jLabel1.setText("Registro Inicial");

        lblEquipoInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEquipoInicial.setText("Nombre del Vehículo: ");

        txtEquipoInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lblMarcaInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblMarcaInicial.setText("Marca:");

        txtMarcaInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Serie:");

        txtSerieInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSerieInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSerieInicialActionPerformed(evt);
            }
        });

        lblCategoriaInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCategoriaInicial.setText("Categoria:");

        cbCategoriaInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbCategoriaInicial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sedán", "SUV", "Pick-up", "Camión liviano", "Camión pesado", "Motocicleta", "Van / Microbús", "Otro" }));

        lblTipoServicioInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTipoServicioInicial.setText("Tipo de Servicio:");

        cbTipoServicioInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbTipoServicioInicial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Preventivo", "Correctivo", "Predictivo", " " }));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Motorización:");

        cbMotorizacionInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbMotorizacionInicial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gasolina", "Diésel Eléctrico ", "Híbrido Gas ", "(GLP / GNC)", "Otro" }));

        lblCostoInicialInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCostoInicialInicial.setText("Costo Inicial:");

        txtCostoInicialInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lblObservacionInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblObservacionInicial.setText("Observación:");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        btnRegistrarInicial.setBackground(new java.awt.Color(28, 67, 95));
        btnRegistrarInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnRegistrarInicial.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrarInicial.setText("Registrar vehículo");
        btnRegistrarInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarInicialActionPerformed(evt);
            }
        });

        btnEliminarInicial.setBackground(new java.awt.Color(204, 51, 51));
        btnEliminarInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnEliminarInicial.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminarInicial.setText("Eliminar Vehículo");
        btnEliminarInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarInicialActionPerformed(evt);
            }
        });

        btnActualizarInicial.setBackground(new java.awt.Color(0, 61, 77));
        btnActualizarInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnActualizarInicial.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizarInicial.setText("Actualizar Datos");
        btnActualizarInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarInicialActionPerformed(evt);
            }
        });

        btnLimpiarInicial.setBackground(new java.awt.Color(220, 230, 240));
        btnLimpiarInicial.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLimpiarInicial.setForeground(new java.awt.Color(28, 67, 95));
        btnLimpiarInicial.setText("Limpiar Formulario");
        btnLimpiarInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarInicialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lblSerieInicialLayout = new javax.swing.GroupLayout(lblSerieInicial);
        lblSerieInicial.setLayout(lblSerieInicialLayout);
        lblSerieInicialLayout.setHorizontalGroup(
            lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblSerieInicialLayout.createSequentialGroup()
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblSerieInicialLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnActualizarInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRegistrarInicial))
                        .addGap(61, 61, 61)
                        .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnEliminarInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpiarInicial)))
                    .addGroup(lblSerieInicialLayout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jLabel1)))
                .addGap(0, 148, Short.MAX_VALUE))
            .addGroup(lblSerieInicialLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblSerieInicialLayout.createSequentialGroup()
                        .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblEquipoInicial)
                            .addComponent(lblMarcaInicial)
                            .addComponent(jLabel2)
                            .addComponent(lblCategoriaInicial)
                            .addComponent(lblTipoServicioInicial)
                            .addComponent(jLabel4))
                        .addGap(80, 80, 80)
                        .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMarcaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEquipoInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSerieInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbCategoriaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbTipoServicioInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbMotorizacionInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(lblSerieInicialLayout.createSequentialGroup()
                        .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCostoInicialInicial)
                            .addComponent(lblObservacionInicial))
                        .addGap(136, 136, 136)
                        .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextArea1)
                            .addComponent(txtCostoInicialInicial, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        lblSerieInicialLayout.setVerticalGroup(
            lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblSerieInicialLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addGap(25, 25, 25)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEquipoInicial)
                    .addComponent(txtEquipoInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblMarcaInicial)
                    .addComponent(txtMarcaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(76, 76, 76)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtSerieInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lblSerieInicialLayout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(lblCategoriaInicial))
                    .addGroup(lblSerieInicialLayout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(cbCategoriaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTipoServicioInicial)
                    .addComponent(cbTipoServicioInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(74, 74, 74)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbMotorizacionInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(83, 83, 83)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCostoInicialInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCostoInicialInicial))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextArea1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblObservacionInicial))
                .addGap(51, 51, 51)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRegistrarInicial)
                    .addComponent(btnEliminarInicial))
                .addGap(26, 26, 26)
                .addGroup(lblSerieInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizarInicial)
                    .addComponent(btnLimpiarInicial))
                .addGap(83, 83, 83))
        );

        jScrollPane3.setViewportView(lblSerieInicial);

        jSplitPane1.setRightComponent(jScrollPane3);

        add(jSplitPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarInicialActionPerformed
    try (Connection cn = new ConexionBD().conectar()) {
        if (cn == null) {
            JOptionPane.showMessageDialog(this, "❌ No se pudo conectar a la base de datos.");
            return;
        }

        // 🧩 Insertar vehículo en la tabla registro_inicial
        String sqlVehiculo = """
            INSERT INTO registro_inicial (vehiculo, marca, categoria, serie, tipo_servicio, motorizacion, costo_inicial, observacion)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        PreparedStatement psVehiculo = cn.prepareStatement(sqlVehiculo, Statement.RETURN_GENERATED_KEYS);
        psVehiculo.setString(1, txtEquipoInicial.getText());
        psVehiculo.setString(2, txtMarcaInicial.getText());
        psVehiculo.setString(3, cbCategoriaInicial.getSelectedItem().toString());
        psVehiculo.setString(4, txtSerieInicial.getText());
        psVehiculo.setString(5, cbTipoServicioInicial.getSelectedItem().toString());
        psVehiculo.setString(6, cbMotorizacionInicial.getSelectedItem().toString());
        psVehiculo.setBigDecimal(7, new java.math.BigDecimal(txtCostoInicialInicial.getText()));
        psVehiculo.setString(8, jTextArea1.getText());
        psVehiculo.executeUpdate();

        // Obtener el ID del registro recién creado
        ResultSet rs = psVehiculo.getGeneratedKeys();
        int idRegistro = 0;
        if (rs.next()) {
            idRegistro = rs.getInt(1);
        }

        // 🧩 Crear automáticamente una tarea de mantenimiento vinculada
        String sqlMantenimiento = """
            INSERT INTO mantenimientos (id_equipo, tipo_mantenimiento, estado, avance, fecha_programada)
            VALUES (?, 'Mantenimiento inicial', 'En diagnóstico', 0, CURDATE())
        """;
        try (PreparedStatement psMant = cn.prepareStatement(sqlMantenimiento)) {
            psMant.setInt(1, idRegistro);
            psMant.executeUpdate();
        }

        cargarDatosVehiculos();
        JOptionPane.showMessageDialog(this, "✅ Vehículo y tarea de mantenimiento registrados correctamente.");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Error al registrar vehículo: " + e.getMessage());
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "⚠️ Error inesperado: " + ex.getMessage());
    }
    }//GEN-LAST:event_btnRegistrarInicialActionPerformed

    private void btnActualizarInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarInicialActionPerformed
    try {
        int filaSeleccionada = jTable1.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un vehículo de la tabla");
            return;
        }

        int id = Integer.parseInt(jTable1.getValueAt(filaSeleccionada, 0).toString());

        try (Connection cn = new ConexionBD().conectar()) {
            if (cn == null) {
                JOptionPane.showMessageDialog(this, "❌ No se pudo conectar a la base de datos.");
                return;
            }

            // CONSULTA DINÁMICA - Solo actualiza los campos modificados
            StringBuilder sql = new StringBuilder("UPDATE registro_inicial SET ");
            ArrayList<Object> parametros = new ArrayList<>();

            // Verificar cada campo y agregarlo si tiene valor
            if (!txtEquipoInicial.getText().trim().isEmpty()) {
                sql.append("vehiculo=?, ");
                parametros.add(txtEquipoInicial.getText().trim());
            }

            if (!txtMarcaInicial.getText().trim().isEmpty()) {
                sql.append("marca=?, ");
                parametros.add(txtMarcaInicial.getText().trim());
            }

            // ComboBox: solo actualizar si tiene valor válido
            if (cbCategoriaInicial.getSelectedItem() != null) {
                String categoria = cbCategoriaInicial.getSelectedItem().toString().trim();
                if (!categoria.isEmpty() && !categoria.equals("Seleccionar...")) {
                    sql.append("categoria=?, ");
                    parametros.add(categoria);
                }
            }

            if (!txtSerieInicial.getText().trim().isEmpty()) {
                sql.append("serie=?, ");
                parametros.add(txtSerieInicial.getText().trim());
            }

            if (cbTipoServicioInicial.getSelectedItem() != null) {
                String tipoServicio = cbTipoServicioInicial.getSelectedItem().toString().trim();
                if (!tipoServicio.isEmpty() && !tipoServicio.equals("Seleccionar...")) {
                    sql.append("tipo_servicio=?, ");
                    parametros.add(tipoServicio);
                }
            }

            if (cbMotorizacionInicial.getSelectedItem() != null) {
                String motorizacion = cbMotorizacionInicial.getSelectedItem().toString().trim();
                if (!motorizacion.isEmpty() && !motorizacion.equals("Seleccionar...")) {
                    sql.append("motorizacion=?, ");
                    parametros.add(motorizacion);
                }
            }

            // Campo numérico
            String costoTexto = txtCostoInicialInicial.getText().trim();
            if (!costoTexto.isEmpty()) {
                sql.append("costo_inicial=?, ");
                parametros.add(new BigDecimal(costoTexto));
            }

            if (!jTextArea1.getText().trim().isEmpty()) {
                sql.append("observacion=?, ");
                parametros.add(jTextArea1.getText().trim());
            }

            // Verificar que al menos un campo cambió
            if (parametros.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay campos para actualizar");
                return;
            }

            // Quitar la coma final
            sql.setLength(sql.length() - 2);
            sql.append(" WHERE id_registro=?");
            parametros.add(id);

            // Preparar y asignar parámetros dinámicamente
            PreparedStatement ps = cn.prepareStatement(sql.toString());
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }

            ps.executeUpdate();
            ps.close();

            cargarDatosVehiculos();
            JOptionPane.showMessageDialog(this, "✅ Vehículo actualizado correctamente");

        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
    }//GEN-LAST:event_btnActualizarInicialActionPerformed

    private void btnEliminarInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarInicialActionPerformed
    try {
        int filaSeleccionada = jTable1.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un vehículo de la tabla");
            return;
        }

        int id = Integer.parseInt(jTable1.getValueAt(filaSeleccionada, 0).toString());

        int confirmar = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de eliminar este vehículo?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirmar == JOptionPane.YES_OPTION) {
            try (Connection cn = new ConexionBD().conectar()) {
                if (cn == null) {
                    JOptionPane.showMessageDialog(this, "❌ No se pudo conectar a la base de datos.");
                    return;
                }

                String sql = "DELETE FROM registro_inicial WHERE id_registro=?";
                PreparedStatement ps = cn.prepareStatement(sql);
                ps.setInt(1, id);
                ps.executeUpdate();
                ps.close();
            }

            cargarDatosVehiculos();
            JOptionPane.showMessageDialog(this, "✅ Vehículo eliminado correctamente.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error inesperado: " + e.getMessage());
    }

    }//GEN-LAST:event_btnEliminarInicialActionPerformed

    private void btnLimpiarInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarInicialActionPerformed
    txtEquipoInicial.setText("");
    txtMarcaInicial.setText("");
    txtSerieInicial.setText("");
    txtCostoInicialInicial.setText("");
    jTextArea1.setText("");
    cbCategoriaInicial.setSelectedIndex(-1);
    cbTipoServicioInicial.setSelectedIndex(-1);
    cbMotorizacionInicial.setSelectedIndex(-1);
    }//GEN-LAST:event_btnLimpiarInicialActionPerformed

    private void txtSerieInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSerieInicialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSerieInicialActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane JScrollPane;
    private javax.swing.JButton btnActualizarInicial;
    private javax.swing.JButton btnEliminarInicial;
    private javax.swing.JButton btnLimpiarInicial;
    private javax.swing.JButton btnRegistrarInicial;
    private javax.swing.JComboBox<String> cbCategoriaInicial;
    private javax.swing.JComboBox<String> cbMotorizacionInicial;
    private javax.swing.JComboBox<String> cbTipoServicioInicial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblCategoriaInicial;
    private javax.swing.JLabel lblCostoInicialInicial;
    private javax.swing.JLabel lblEquipoInicial;
    private javax.swing.JLabel lblMarcaInicial;
    private javax.swing.JLabel lblObservacionInicial;
    private javax.swing.JPanel lblSerieInicial;
    private javax.swing.JLabel lblTipoServicioInicial;
    private javax.swing.JTextField txtCostoInicialInicial;
    private javax.swing.JTextField txtEquipoInicial;
    private javax.swing.JTextField txtMarcaInicial;
    private javax.swing.JTextField txtSerieInicial;
    // End of variables declaration//GEN-END:variables
}
