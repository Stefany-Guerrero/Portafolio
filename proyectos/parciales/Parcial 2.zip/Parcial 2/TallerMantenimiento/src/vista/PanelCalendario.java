package vista;

import com.toedter.calendar.JCalendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import conexion.ConexionBD;
import java.util.HashSet;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;

public class PanelCalendario extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger =
        java.util.logging.Logger.getLogger(PanelCalendario.class.getName());

    private final HashSet<String> fechasRegistradas = new HashSet<>();

    public PanelCalendario() {
        initComponents(); // (NetBeans) No tocar

        // 🔹 Acomodar el layout correctamente
        PanelCalendario.setLayout(new java.awt.BorderLayout());
        PanelCalendario.add(jPanel1, java.awt.BorderLayout.NORTH);
        PanelCalendario.add(jScrollPane1, java.awt.BorderLayout.CENTER);
        PanelCalendario.add(jPanelFecha, java.awt.BorderLayout.SOUTH);

        // 🔹 Mostrar el label con formato visible
        lblFechaSeleccionada.setVisible(true);
        lblFechaSeleccionada.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
        lblFechaSeleccionada.setText("📅 Fecha seleccionada: (ninguna)");

        // 🔹 Configurar columnas de la tabla
        DefaultTableModel model = new DefaultTableModel(
            new Object[][]{},
            new String[]{"ID", "Vehículo", "Marca", "Categoría", "Fecha Ingreso", "Fecha Salida"}
        );
        jTable1.setModel(model);

        // 🔹 Mostrar fecha inicial
        actualizarFechaSeleccionada();

        // 🔹 Cargar y marcar fechas desde la base de datos
        cargarFechasDesdeBD();
        marcarFechasRegistradas();

        // 🔹 Actualizar tabla y label al hacer clic en un día
        jCalendar2.getDayChooser().addPropertyChangeListener("day", evt -> {
            actualizarFechaSeleccionada();
            mostrarRegistrosDeFecha();
            marcarFechasRegistradas(); // 🔸 vuelve a marcar
        });

        // 🔹 Recolorear los días si cambia el mes o el año
        jCalendar2.getMonthChooser().addPropertyChangeListener("month", evt -> marcarFechasRegistradas());
        jCalendar2.getYearChooser().addPropertyChangeListener("year", evt -> marcarFechasRegistradas());
    }

    public javax.swing.JPanel getPanel() {
        return (javax.swing.JPanel) this.getContentPane();
    }

    // 🔹 Mostrar la fecha seleccionada en el label
    private void actualizarFechaSeleccionada() {
        Date fecha = jCalendar2.getDate();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        lblFechaSeleccionada.setText("📅 Fecha seleccionada: " + formato.format(fecha));
    }

    // 🔹 Cargar fechas desde la BD
    private void cargarFechasDesdeBD() {
        ConexionBD conexion = new ConexionBD();
        try (Connection con = conexion.conectar()) {
            if (con == null) {
                System.out.println("❌ No se pudo conectar a la base de datos.");
                return;
            }

            String sql = """
                SELECT fecha_ingreso AS fecha FROM registro_inicial
                UNION
                SELECT fecha_ingreso AS fecha FROM equipos
                UNION
                SELECT fecha_salida AS fecha FROM equipos WHERE fecha_salida IS NOT NULL;
            """;

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            fechasRegistradas.clear();
            while (rs.next()) {
                fechasRegistradas.add(rs.getString("fecha"));
            }

            System.out.println("✅ Fechas cargadas desde la BD: " + fechasRegistradas.size());
        } catch (SQLException e) {
            System.out.println("⚠️ Error al cargar fechas: " + e.getMessage());
        }
    }

    // 🔹 Marcar los días registrados (mantiene color verde)
    private void marcarFechasRegistradas() {
        java.awt.Component[] dias = jCalendar2.getDayChooser().getDayPanel().getComponents();
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

        for (java.awt.Component dia : dias) {
            if (dia instanceof JButton botonDia) {
                try {
                    int numeroDia = Integer.parseInt(botonDia.getText());
                    java.util.Calendar cal = jCalendar2.getCalendar();
                    cal.set(java.util.Calendar.DAY_OF_MONTH, numeroDia);

                    String fecha = formato.format(cal.getTime());
                    if (fechasRegistradas.contains(fecha)) {
                        botonDia.setBackground(new java.awt.Color(102, 205, 170)); // Verde agua
                        botonDia.setOpaque(true);
                        botonDia.setBorderPainted(false);
                    } else {
                        botonDia.setBackground(java.awt.Color.WHITE);
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
        jCalendar2.repaint();
    }

    // 🔹 Mostrar los registros del día seleccionado
    private void mostrarRegistrosDeFecha() {
        Date fecha = jCalendar2.getDate();
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
        String fechaSeleccionada = formato.format(fecha);

        ConexionBD conexion = new ConexionBD();
        try (Connection con = conexion.conectar()) {
            if (con == null) return;

            String sql = """
                SELECT id_equipo AS ID, vehiculo, marca, categoria, fecha_ingreso, fecha_salida
                FROM equipos
                WHERE fecha_ingreso = ? OR fecha_salida = ?
                UNION
                SELECT id_registro AS ID, vehiculo, marca, categoria, fecha_ingreso, NULL AS fecha_salida
                FROM registro_inicial
                WHERE fecha_ingreso = ?;
            """;

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, fechaSeleccionada);
            ps.setString(2, fechaSeleccionada);
            ps.setString(3, fechaSeleccionada);

            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("ID"),
                    rs.getString("vehiculo"),
                    rs.getString("marca"),
                    rs.getString("categoria"),
                    rs.getString("fecha_ingreso"),
                    rs.getString("fecha_salida")
                });
            }

            jTable1.repaint();

        } catch (SQLException e) {
            System.out.println("⚠️ Error al mostrar registros: " + e.getMessage());
        }

        // 🔸 Asegura que el label siga visible al actualizar
        lblFechaSeleccionada.setVisible(true);
        lblFechaSeleccionada.repaint();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelCalendario = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jCalendar2 = new com.toedter.calendar.JCalendar();
        jPanelFecha = new javax.swing.JPanel();
        lblFechaSeleccionada = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.FlowLayout());

        PanelCalendario.setBackground(new java.awt.Color(255, 255, 255));
        PanelCalendario.setPreferredSize(new java.awt.Dimension(1920, 1080));
        PanelCalendario.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(new java.awt.BorderLayout());

        jCalendar2.setBackground(new java.awt.Color(230, 240, 255));
        jCalendar2.setDecorationBackgroundColor(new java.awt.Color(200, 220, 255));
        jCalendar2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jCalendar2.setMaximumSize(new java.awt.Dimension(1920, 350));
        jCalendar2.setMinimumSize(new java.awt.Dimension(1920, 400));
        jCalendar2.setPreferredSize(new java.awt.Dimension(1920, 650));
        jCalendar2.setSundayForeground(new java.awt.Color(200, 0, 0));
        jCalendar2.setTodayButtonText("180,220,180");
        jCalendar2.setWeekdayForeground(new java.awt.Color(0, 0, 128));
        jPanel1.add(jCalendar2, java.awt.BorderLayout.CENTER);

        PanelCalendario.add(jPanel1, java.awt.BorderLayout.PAGE_START);

        jPanelFecha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lblFechaSeleccionada.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFechaSeleccionada.setText("Fecha Seleccionada:");

        javax.swing.GroupLayout jPanelFechaLayout = new javax.swing.GroupLayout(jPanelFecha);
        jPanelFecha.setLayout(jPanelFechaLayout);
        jPanelFechaLayout.setHorizontalGroup(
            jPanelFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFechaLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(lblFechaSeleccionada)
                .addContainerGap(1756, Short.MAX_VALUE))
        );
        jPanelFechaLayout.setVerticalGroup(
            jPanelFechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelFechaLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(lblFechaSeleccionada)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelCalendario.add(jPanelFecha, java.awt.BorderLayout.CENTER);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        PanelCalendario.add(jScrollPane1, java.awt.BorderLayout.PAGE_END);

        getContentPane().add(PanelCalendario);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PanelCalendario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelCalendario;
    private com.toedter.calendar.JCalendar jCalendar2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelFecha;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblFechaSeleccionada;
    // End of variables declaration//GEN-END:variables
}