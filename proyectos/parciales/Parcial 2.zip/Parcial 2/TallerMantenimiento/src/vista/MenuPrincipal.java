package vista;

import vista.PanelMantenimiento;
import vista.PanelCalendario;
import vista.RegistroInicial;
import vista.RegistroFinal;
import javax.swing.JFrame;

/**
 *
 * @author Admin
 */
public class MenuPrincipal extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MenuPrincipal.class.getName());

    /**
     * Creates new form MenuPrincipal
     */
    public MenuPrincipal() {
        initComponents();

        // Configuración general
        setTitle("Panel Principal - Taller Mantenimiento");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        setLocationRelativeTo(null);

        // Crear paneles
        PanelMantenimiento panelMantenimiento = new PanelMantenimiento();
        PanelCalendario panelCalendario = new PanelCalendario();
        RegistroInicial panelRegistroInicial = new RegistroInicial();
        RegistroFinal panelRegistroFinal = new RegistroFinal();

        // Configurar el JTabbedPane
        jTabbedPane1.removeAll();
        jTabbedPane1.addTab("Registro Inicial", panelRegistroInicial);
        jTabbedPane1.addTab("Mantenimientos", panelMantenimiento);
        jTabbedPane1.addTab("Registro Final", panelRegistroFinal);

        // 🔹 Aquí está el cambio importante
        // Usamos el método getPanel() para insertar solo el contenido del JFrame del calendario
        jTabbedPane1.addTab("Calendario", panelCalendario.getPanel());

        jTabbedPane1.revalidate();
        jTabbedPane1.repaint();

        // Agregar al JFrame
        add(jTabbedPane1);

        // Refrescar todo
        revalidate();
        repaint();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(null);
        setMinimumSize(null);
        setPreferredSize(new java.awt.Dimension(1900, 1080));

        jTabbedPane1.setMaximumSize(new java.awt.Dimension(1920, 1080));
        jTabbedPane1.setMinimumSize(new java.awt.Dimension(1920, 1080));
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(1920, 1080));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1920, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
