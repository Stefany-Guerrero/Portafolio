package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private final String urlLocal = "jdbc:mysql://127.0.0.1:3306/taller_mantenimiento?useSSL=false&serverTimezone=UTC";
    private final String userLocal = "root";
    private final String passLocal = "Febrero_0214Agosto";

    private final String urlServidor = "jdbc:mysql://192.168.56.101:3306/taller_mantenimiento?useSSL=false&serverTimezone=UTC";
    private final String userServidor = "adminlab";
    private final String passServidor = "hola14";

    // =========================================================
    // 🔸 Conexión principal (XAMPP)
    // =========================================================
    public Connection conectarServidorPrincipal() {
        try {
            Connection cn = DriverManager.getConnection(urlLocal, userLocal, passLocal);
            System.out.println("✅ Conectado exitosamente al servidor principal (XAMPP)");
            return cn;
        } catch (SQLException e) {
            System.out.println("⚠️ No se pudo conectar al servidor principal (XAMPP): " + e.getMessage());
            return null;
        }
    }

    // =========================================================
    // 🔸 Conexión de respaldo (VM Windows Server)
    // =========================================================
    public Connection conectarServidorRespaldo() {
        try {
            Connection cn = DriverManager.getConnection(urlServidor, userServidor, passServidor);
            System.out.println("✅ Conectado al servidor de respaldo (Windows Server)");
            return cn;
        } catch (SQLException e) {
            System.out.println("⚠️ No se pudo conectar al servidor de respaldo: " + e.getMessage());
            return null;
        }
    }

    // =========================================================
    // 🔸 Método inteligente: conecta al primero disponible
    // =========================================================
    public Connection conectar() {
        Connection cn = conectarServidorPrincipal();
        if (cn != null) return cn; // si conecta al XAMPP, usa esa
        System.out.println("🔁 Intentando conectar al servidor de respaldo...");
        cn = conectarServidorRespaldo();
        if (cn == null) {
            System.out.println("❌ No se pudo conectar a ningún servidor MySQL.");
        }
        return cn;
    }

    public Connection conectarServidor() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Connection conectarLocal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
